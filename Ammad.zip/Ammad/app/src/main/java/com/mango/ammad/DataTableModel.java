package com.mango.ammad;

public class DataTableModel {
    public static final String KEY_ID ="id";
    public static final String KEY_FOREIGN_KEY ="id_user";
    public static final String KEY_Student ="name";
    public static final String KEY_Course ="roll_number";
    public static final String DATA_MODEL_TABLE="DataTable";

}
