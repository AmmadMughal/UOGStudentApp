package com.mango.ammad;

public class UserModel {
    public static final String KEY_ID ="id";
    public static final String KEY_NAME ="name";
    public static final String KEY_ROLL_NUMBER ="roll_number";
    public static final String KEY_EMAIL ="email";
    public static final String KEY_PASSWORD ="password";
    public static final String USER_TABLE="UserTable";
    public static UserData userData=null;
}
